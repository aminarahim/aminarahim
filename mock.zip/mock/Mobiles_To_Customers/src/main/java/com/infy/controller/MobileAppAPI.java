package com.infy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.infy.model.Customer;
import com.infy.model.Mobile;
import com.infy.service.CustomerService;
import com.infy.service.MobileService;

@RestController
public class MobileAppAPI {
	
	
	 @Autowired DiscoveryClient client;
	@Autowired
	private MobileService mobileService;
	
	@Autowired
	private CustomerService customerService;
	
	
	@Autowired
	public Environment environment;

	@RequestMapping(value = "/mobile", method = RequestMethod.GET)
	public ResponseEntity<List<Mobile>> getMobileDetails()
			throws Exception {
		ResponseEntity<List<Mobile>> response = null;

		try {
			List<Mobile> mobiles = mobileService.getMobileDetails();
			

			response = new ResponseEntity<List<Mobile>>(mobiles,
					HttpStatus.CREATED);

		} catch (Exception exception) {
			String errorMessage = environment.getProperty(exception
					.getMessage());

			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
					errorMessage, exception);

		}
		return response;
	}

	
	@RequestMapping(value = "/customer", method = RequestMethod.GET)
	public ResponseEntity<List<Customer>> getCustomerDetails()
			throws Exception {
		ResponseEntity<List<Customer>> response = null;

		try {
			List<Customer> customers = customerService.getCustomerDetails();
			

			response = new ResponseEntity<List<Customer>>(customers,
					HttpStatus.CREATED);

		} catch (Exception exception) {
			String errorMessage = environment.getProperty(exception
					.getMessage());

			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
					errorMessage, exception);

		}
		return response;
	}

	
	@RequestMapping(value = "/customer/{customerId}", method = RequestMethod.GET)
	public ResponseEntity<Customer> getCustomerByCustomerId(
			@PathVariable Integer customerId) throws Exception {
		
		ResponseEntity<Customer> response = null;

		try {
			Customer customer = customerService
					.getCustomerByCustomerId(customerId);
			
			response = new ResponseEntity<Customer>(customer,
					HttpStatus.OK);
			
		} catch (Exception exception) {
			String errorMessage = environment.getProperty("Service.CUSTOMER_UNAVAILABLE");

			throw new ResponseStatusException(HttpStatus.NOT_FOUND,
					errorMessage, exception);

		}

		return response;
	}

}
