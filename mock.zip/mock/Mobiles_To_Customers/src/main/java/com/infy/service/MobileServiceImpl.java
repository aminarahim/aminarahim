package com.infy.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.MobileDAO;
import com.infy.model.Customer;
import com.infy.model.Mobile;



@Service(value = "mobileService")
@Transactional
public class MobileServiceImpl implements MobileService {

	@Autowired
	private MobileDAO mobileDAO;

	
	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	

	// DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public List<Mobile> getMobileDetails() throws Exception {
		List<Mobile> mobileList = mobileDAO.getMobileDetails();
		if (mobileList.isEmpty()) {
			throw new Exception("Service.NO_LOAN_FOUND");
		}

		return mobileList;
		
	}

}
