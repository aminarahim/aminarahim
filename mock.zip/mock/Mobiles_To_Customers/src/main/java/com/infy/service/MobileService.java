package com.infy.service;

import java.util.List;

import com.infy.model.Customer;
import com.infy.model.Mobile;

public interface MobileService {

	public List<Mobile> getMobileDetails() throws Exception;

	

}
